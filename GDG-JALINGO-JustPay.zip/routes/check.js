const http = require("https");
const crypto = require("crypto");

var express = require('express');
var router = express.Router();

/* GET */
router.get('/', function(req, res, next) { 
var bvn = req.query.bvn;

      
// Replace with actual credentials
const sandboxKey = "a19b9d5cb77ebcc612d994fc0eed3975";
const username = "fortuneodesanya@gmail.com"

// change hostname to match Interface URL on innovation sandbox dashboard
const hostname = "sandboxapi.fsi.ng";
    
 /*       
const axios = require('axios')

axios({
	method: 'get',
	baseURL: 'https://sandboxapi.fsi.ng',
	url: '/sterling/TransferAPIs/api/Spay/InterbankNameEnquiry?',
	params: {
		  Referenceid: "01",
		  RequestType: "01",
		  Translocation: "01",
		  ToAccount: "0037514056",
		  destinationbankcode: "000001"
		},
	headers: {
		"Sandbox-Key": sandboxKey,
		"Ocp-Apim-Subscription-Key": "1cc664165bd4490e97019c61a492d19a",
		"Ocp-Apim-Trace": "true",
		"Appid": "69",
		"Content-Type": "application/json",
		"ipval": 0
		}
	})
	.then((response) => console.log(response))
	.catch((error) => console.log(error))
	

});
*/	
    
// Converting organization code to base 64
const organisationCode = Buffer.from(username).toString("base64");
const crypt = (aesKey, ivKey) => ({
  // Encrypt BVN
  encrypt: (plainText) => {
    const cipher = crypto.createCipheriv("aes-128-cbc", Buffer.from(aesKey), ivKey);
    let encrypted = cipher.update(plainText);
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return encrypted.toString("hex");
  },
  // Decrypt Response
  decrypt: (text) => {
    const textParts = text.split(":");
    const encryptedText = Buffer.from(textParts.join(":"), "hex");
    const decipher = crypto.createDecipheriv("aes-128-cbc", Buffer.from(aesKey), ivKey);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted.toString();
  },
});

// Reset Sandbox Credentials
async function Reset() {
  let data = "";
  const options = {
    hostname: hostname,
    path: "/nibss/bvnr/Reset",
    method: "POST",
    // setting request headers
    headers: {
      "Sandbox-Key": sandboxKey,
      OrganisationCode: organisationCode,
    },
  };

  return new Promise((resolve, reject) => {
    const request = http.request(options, (response) => {
      response.on("error", error => reject(error));

      response.on('data', (chunk) => {
        data += chunk;
      });

      response.on("end", () => resolve({
        aesKey: response.headers.aes_key,
        ivKey: response.headers.ivkey,
        password: response.headers.password,
      }));
    });

    request.on("error", (error) => reject(error));
    request.end();
  });
}

// Verify BVN
async function BVN() {
  try {
      //console.log(bvn);
    // Data gotten from Reset() headers
    const { aesKey, ivKey, password } = await Reset();
    const cr = crypt(aesKey, ivKey);

    // Signing signatureheader(username, currentdate and password) with SHA256
    const today = new Date().toJSON().slice(0, 10).replace(/-/g, "");
    const signatureHeader = crypto.createHash("sha256").update(`${username}${today}${password}`).digest("hex");
    const authorizationHeader = Buffer.from(`${username}:${password}`).toString("base64");
    const signatureMethodHeader = "SHA256";
    const payload = `{"BVN": "12234568899"}`;
    const encrypted = cr.encrypt(payload);

    console.log("SENDING PAYLOAD");
    console.log(payload);

    const options = {
      hostname: hostname,
      path: "/nibss/bvnr/VerifySingleBVN",
      method: "POST",
      headers: {
        "Sandbox-Key": sandboxKey,
        OrganisationCode: organisationCode,
        Authorization: authorizationHeader,
        SIGNATURE: signatureHeader,
        SIGNATURE_METH: signatureMethodHeader,
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    };

    let data = "";

    const request = http.request(options, (response) => {
      response.on("error", error => {
        throw error;
      });

      response.on('data', (chunk) => {
        data += chunk;
      });

      response.on("end", () => {
        console.log("\nDECRYPTED RESPONSE");
        console.log(JSON.parse(cr.decrypt(data)));
      });
    });

    console.log("\nSENDING ENCYRPTED REQUEST");
    console.log(encrypted);

    request.write(encrypted);
    request.end();
  } catch (error) {
    console.log(error);
  }
}

BVN();
   // res.render(BVN());

  //  var bvn = req.body.bvn;
  res.send(bvn);
  
});

module.exports = router;