function newdisplay() {
    document.getElementsByClassName("log").

}